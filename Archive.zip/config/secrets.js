export const cfAccessToken = '5974a9eac1d53775b9863d85f55bd6479980860a4310583da9e9415c70411b85'
export const cfSpaceId = '7alamuzf2nhi'
export const cfHostPath = 'http://cdn.contentful.com'
